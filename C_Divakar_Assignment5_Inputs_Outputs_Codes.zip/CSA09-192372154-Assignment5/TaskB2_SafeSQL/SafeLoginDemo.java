import java.sql.*;

public class SafeLoginDemo {
    public static void main(String[] args) throws Exception {
        String url = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/assignment5");
        String user = System.getenv().getOrDefault("DB_USER", "root");
        String password = System.getenv().getOrDefault("DB_PASSWORD", "");
        String suppliedId = args.length > 0 ? args[0] : "test-user";
        String suppliedPassword = args.length > 1 ? args[1] : "wrong-password";

        String sql = "SELECT COUNT(*) FROM app_user WHERE user_id = ? AND password_hash = ?";
        try (Connection c = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, suppliedId);
            ps.setString(2, suppliedPassword); // Demo only: real apps verify a salted password hash.
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                System.out.println(rs.getInt(1) == 1 ? "Login accepted" : "Login rejected");
            }
        }
    }
}
