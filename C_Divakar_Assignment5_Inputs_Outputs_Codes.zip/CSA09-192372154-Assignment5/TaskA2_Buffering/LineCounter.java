import java.io.*;

public class LineCounter {
    public static long countLines(String file) throws IOException {
        long count = 0;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file), 64 * 1024)) {
            int b;
            while ((b = in.read()) != -1) if (b == '\n') count++;
        }
        return count;
    }
    public static void main(String[] args) throws Exception {
        String file = args.length > 0 ? args[0] : "sample.txt";
        System.out.println("Line-feed count: " + countLines(file));
    }
}
