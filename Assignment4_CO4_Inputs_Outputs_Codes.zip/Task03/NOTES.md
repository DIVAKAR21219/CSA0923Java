The result row is demonstration data, as stated in the report. Replace performSearch()'s demonstration block with a real library service/database query when available.
