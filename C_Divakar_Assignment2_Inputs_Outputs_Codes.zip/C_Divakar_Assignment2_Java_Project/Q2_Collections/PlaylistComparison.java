import java.util.*;

public class PlaylistComparison {
    public static void main(String[] args) {
        int n = 10;
        List<String> array = new ArrayList<>();
        List<String> linked = new LinkedList<>();
        Deque<String> deque = new ArrayDeque<>();
        for (int i = 1; i <= n; i++) {
            String song = "Song" + i;
            array.add(song); linked.add(song); deque.addLast(song);
        }
        System.out.println("ArrayList middle item: " + array.get(n / 2));
        System.out.println("LinkedList middle item: " + linked.get(n / 2));
        array.add(0, "NewSong");
        linked.add(0, "NewSong");
        deque.addFirst("NewSong");
        System.out.println("ArrayList first: " + array.get(0));
        System.out.println("LinkedList first: " + linked.get(0));
        System.out.println("ArrayDeque first: " + deque.peekFirst());
        deque.removeFirst();
        System.out.println("ArrayDeque size after removeFirst: " + deque.size());
    }
}
