import java.util.Arrays;

public class TicketBenchmark {
    static String withString(String[] fields) {
        String result = "";
        for (String field : fields) result = result + field + "|";
        return result;
    }
    static String withBuilder(String[] fields) {
        StringBuilder result = new StringBuilder();
        for (String field : fields) result.append(field).append('|');
        return result.toString();
    }
    static String withBuffer(String[] fields) {
        StringBuffer result = new StringBuffer();
        for (String field : fields) result.append(field).append('|');
        return result.toString();
    }
    static long time(Runnable task, int reps) {
        for (int i = 0; i < 3; i++) task.run();
        long start = System.nanoTime();
        for (int i = 0; i < reps; i++) task.run();
        return (System.nanoTime() - start) / reps;
    }
    public static void main(String[] args) {
        String[] small = {"PNR:123", "Name:Divakar", "Coach:S1", "Berth:21"};
        String[] medium = new String[50], large = new String[200];
        Arrays.fill(medium, "ticket-field");
        Arrays.fill(large, "ticket-field");
        String[][] workloads = {small, medium, large};
        int[] reps = {10000, 2000, 500};
        for (int i = 0; i < workloads.length; i++) {
            final String[] data = workloads[i];
            final int n = reps[i];
            System.out.println("Workload fields=" + data.length);
            System.out.println("String ns/op=" + time(() -> withString(data), n));
            System.out.println("StringBuilder ns/op=" + time(() -> withBuilder(data), n));
            System.out.println("StringBuffer ns/op=" + time(() -> withBuffer(data), n));
        }
    }
}
