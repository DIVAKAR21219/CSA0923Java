# Campus Smart-Parking System - Assignment 1

**Student:** C Divakar  
**Register Number:** 192372154  
**Course Code:** CSA0923  
**Assignment:** CO1 - Java Fundamentals and Object-Oriented Programming

## Contents
- `src/ParkingSystem.java` - complete runnable Java implementation.
- `inputs/sample-inputs.txt` - test data and assumptions used by the demonstration.
- `outputs/actual-output.txt` - output captured by compiling and running this source.
- `outputs/expected-output.txt` - expected test results.
- `task-notes/` - mapping of assignment tasks to the implementation.

## Requirements
Java JDK 8 or later. This project was compiled and run with OpenJDK 21.

## Compile and run
From this project directory:

```bash
javac -d out src/ParkingSystem.java
java -cp out ParkingSystem
```

## Main concepts demonstrated
Classes and objects, constructors, encapsulation, inheritance, method overriding, compile-time and runtime polymorphism, abstraction, interfaces, static members, arrays (including unequal floor capacities), exception/validation checks, and `HashMap` ticket storage.

## Assumptions from the assignment
- Two-wheeler: Rs 10/hour
- Car/electric car: Rs 30/hour
- Delivery van: Rs 60/hour
- EV charging: Rs 12/kWh
- Every started hour is billed as a full hour.
- A valid pass makes the parking fee zero; charging is calculated separately.

These are illustrative assignment rates, not verified campus tariffs. The sample `main` method uses fixed demonstration data so the output is repeatable. Update the test values in `main` or extend the program with `Scanner` input if interactive input is required by your instructor.
