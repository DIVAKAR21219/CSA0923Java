import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

public class PassStore {
    private final Path path;
    public PassStore(Path path) { this.path = path; }

    // This teaching implementation uses a simple comma-separated format.
    // For fields containing commas/quotes/newlines, use a full RFC 4180 CSV library.
    private String encode(String[] f) {
        return String.join(",", f);
    }
    public void add(String passId, String regNo, String name, int routeNo,
                    LocalDate validity, double amount) throws IOException {
        if (passId.isBlank() || regNo.isBlank() || routeNo < 0 || amount < 0)
            throw new IllegalArgumentException("Invalid pass data");
        Files.createDirectories(path.toAbsolutePath().getParent());
        try (BufferedWriter w = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(encode(new String[]{passId, regNo, name, String.valueOf(routeNo),
                    validity.toString(), String.valueOf(amount)}));
            w.newLine();
        }
    }
    public String[] find(String passId) throws IOException {
        if (!Files.exists(path)) return null;
        try (BufferedReader r = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line; int lineNo = 0;
            while ((line = r.readLine()) != null) {
                lineNo++;
                try {
                    String[] f = line.split(",", -1);
                    if (f.length != 6) throw new IllegalArgumentException("wrong field count");
                    Integer.parseInt(f[3]); LocalDate.parse(f[4]); double amount = Double.parseDouble(f[5]);
                    if (amount < 0) throw new IllegalArgumentException("negative amount");
                    if (f[0].equals(passId)) return f;
                } catch (RuntimeException ex) {
                    System.err.println("Skipping damaged line " + lineNo + ": " + ex.getMessage());
                }
            }
        }
        return null;
    }
    public List<String[]> listByRoute(int route) throws IOException {
        List<String[]> result = new ArrayList<>();
        if (!Files.exists(path)) return result;
        try (BufferedReader r = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line; int lineNo = 0;
            while ((line = r.readLine()) != null) {
                lineNo++;
                try {
                    String[] f = line.split(",", -1);
                    if (f.length != 6) throw new IllegalArgumentException("wrong field count");
                    int rowRoute = Integer.parseInt(f[3]);
                    LocalDate.parse(f[4]); double amount = Double.parseDouble(f[5]);
                    if (amount < 0) throw new IllegalArgumentException("negative amount");
                    if (rowRoute == route) result.add(f);
                } catch (RuntimeException ex) {
                    System.err.println("Skipping damaged line " + lineNo + ": " + ex.getMessage());
                }
            }
        }
        return result;
    }
}
