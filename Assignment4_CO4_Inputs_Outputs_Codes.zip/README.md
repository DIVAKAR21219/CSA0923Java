# Assignment 4 – CO4: Event-Driven GUI Design
Student: C Divakar | Register No.: 192372154 | Course: CSA0923

This archive is organised into `Task01` through `Task06`. Each task contains Java source where applicable, sample input/action data, and expected output notes. The code is a learning/demo package based on the uploaded 16-page assignment report.

## Requirements
- JDK 8 or later
- Swing/AWT are included with the JDK.
- Task 6 database files require MySQL 8+ and MySQL Connector/J at runtime.

## Compile and run
Open a terminal in the relevant task folder:
```bash
javac FileName.java
java ClassName
```
Examples:
```bash
cd Task03 && javac LibrarySearch.java && java LibrarySearch
cd Task04 && javac DrawPad.java && java DrawPad
cd Task05 && javac Converter.java && java Converter
```
Task 2: `javac AppointmentDesk.java && java AppointmentDesk`
Task 1: `javac FeeWindow.java && java FeeWindow`

## Inputs and outputs
- `inputs/` contains sample values or interaction steps.
- `outputs/expected-output.txt` describes the expected visible result.
- GUI tasks take input through their windows; the input files are test cases, not redirected standard input.

## Important verification notes
1. Compile and run every program on your own computer before submission.
2. Capture genuine screenshots of tested interactions; this archive does not contain fabricated screenshots.
3. Task 6 JDBC access requires a configured MySQL database. Update connection settings using environment variables and add MySQL Connector/J to the classpath.
4. Record your actual Java version using `java -version`.
5. The assignment brief calls for progressive Git commits and a final repository named `CSA09-192372154-Assignment4` (confirm with faculty if using an existing repository).
