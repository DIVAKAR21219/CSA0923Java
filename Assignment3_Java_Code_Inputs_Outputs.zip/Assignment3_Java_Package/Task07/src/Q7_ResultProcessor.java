import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class Q7_ResultProcessor {
    static class Result {
        final String file;
        final boolean success;
        final int score;
        final String message;

        Result(String file, boolean success, int score, String message) {
            this.file = file;
            this.success = success;
            this.score = score;
            this.message = message;
        }
    }

    static class ProcessFile implements Callable<Result> {
        private final Path path;
        ProcessFile(Path path) { this.path = path; }

        public Result call() {
            try {
                String value = Files.readString(path).trim();
                int score = Integer.parseInt(value);
                if (score < 0 || score > 100)
                    throw new IllegalArgumentException("Score must be 0 to 100");
                return new Result(path.getFileName().toString(), true, score, "OK");
            } catch (IOException | IllegalArgumentException e) {
                return new Result(path.getFileName().toString(), false, 0,
                        e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Path folder = Paths.get("input/scores");
        Files.createDirectories(folder);
        Files.writeString(folder.resolve("student1.txt"), "85");
        Files.writeString(folder.resolve("student2.txt"), "72");
        Files.writeString(folder.resolve("student3.txt"), "corrupt");

        ExecutorService pool = Executors.newFixedThreadPool(4);
        ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
        List<Future<Result>> futures = new ArrayList<>();

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder, "*.txt")) {
            List<Path> paths = new ArrayList<>();
            for (Path path : stream) paths.add(path);
            paths.sort(Comparator.comparing(p -> p.getFileName().toString()));
            for (Path path : paths) futures.add(pool.submit(new ProcessFile(path)));
        }

        try {
            for (Future<Result> future : futures) results.add(future.get());
        } finally {
            pool.shutdown();
        }

        int success = 0, failure = 0, total = 0;
        for (Result result : results) {
            if (result.success) {
                success++;
                total += result.score;
                System.out.println("Processed: " + result.file + " = " + result.score);
            } else {
                failure++;
                System.out.println("Failed: " + result.file + " - " + result.message);
            }
        }
        System.out.println("Successful files: " + success);
        System.out.println("Failed files: " + failure);
        System.out.println("Total score of successful files: " + total);
    }
}
