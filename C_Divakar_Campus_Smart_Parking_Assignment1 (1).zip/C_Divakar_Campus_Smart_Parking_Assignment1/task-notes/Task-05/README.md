# Task 5 - Static members and object life cycle
ParkingTicket.nextId is static and shared across ticket objects. ParkingFacility.totalFacilities tracks created facilities.
