import java.io.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDate;

public class PassLoader {
    private static final String INSERT =
        "INSERT INTO bus_pass(pass_id, register_no, student_name, route_no, validity_date, amount_paid) " +
        "VALUES (?, ?, ?, ?, ?, ?)";

    public static int load(Connection c, Path csv, int batchSize) throws Exception {
        if (batchSize < 1) throw new IllegalArgumentException("batchSize must be positive");
        boolean oldAutoCommit = c.getAutoCommit();
        int submitted = 0, pending = 0;
        c.setAutoCommit(false);
        try (BufferedReader reader = Files.newBufferedReader(csv);
             PreparedStatement ps = c.prepareStatement(INSERT)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] f = line.split(",", -1);
                if (f.length != 6) throw new IllegalArgumentException("Expected 6 fields: " + line);
                ps.setString(1, f[0]);
                ps.setString(2, f[1]);
                ps.setString(3, f[2]);
                ps.setInt(4, Integer.parseInt(f[3]));
                ps.setDate(5, Date.valueOf(LocalDate.parse(f[4])));
                ps.setBigDecimal(6, new BigDecimal(f[5]));
                ps.addBatch();
                pending++;
                if (pending == batchSize) {
                    ps.executeBatch();
                    submitted += pending;
                    pending = 0;
                }
            }
            if (pending > 0) {
                ps.executeBatch();
                submitted += pending;
            }
            c.commit();
            return submitted;
        } catch (Exception e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(oldAutoCommit);
        }
    }

    public static void main(String[] args) throws Exception {
        String url = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/assignment5");
        String user = System.getenv().getOrDefault("DB_USER", "root");
        String password = System.getenv().getOrDefault("DB_PASSWORD", "");
        Path file = Path.of(args.length > 0 ? args[0] : "passes.csv");
        try (Connection c = DriverManager.getConnection(url, user, password)) {
            System.out.println("Rows committed: " + load(c, file, 1000));
        }
    }
}
