# Task 9 - Abstraction
Vehicle is abstract and defines the ratePerHour() contract. Chargeable is an interface for optional charging capability.
