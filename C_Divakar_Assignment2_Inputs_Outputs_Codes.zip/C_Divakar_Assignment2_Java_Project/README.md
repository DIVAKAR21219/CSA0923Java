# CSA09-192372154-Assignment2

**Student:** C Divakar  
**Register Number:** 192372154  
**Course Code:** CSA0923  
**Assignment:** Java – Assignment 2 (CO2)

## Contents
- Q1: String, StringBuilder and StringBuffer benchmark
- Q2: ArrayList, LinkedList and ArrayDeque
- Q3: equals() and hashCode() with HashSet
- Q4: HashMap, TreeMap and LinkedHashMap
- Q5: Generics and Comparator leaderboard
- Q6: PriorityQueue triage
- Q7: Diagnose and redesign String concatenation using StringBuilder

Each Q folder contains a `.java` source file, `input.txt`, and `expected_output.txt`.

## Compile and run
Open a terminal in the relevant Q folder. Example:

```bash
javac TicketBenchmark.java
java TicketBenchmark
```

Use the matching public class name for each folder:
- Q1: `TicketBenchmark`
- Q2: `PlaylistComparison`
- Q3: `Attendance`
- Q4: `PharmacyMaps`
- Q5: `LeaderboardDemo`
- Q6: `Triage`
- Q7: `StringBuilderRedesign`

## Important evidence note
Q1 benchmark timings depend on the computer and JVM. Run each benchmark several times and record your own measured values. The `expected_output.txt` files describe deterministic outputs or the type of output to expect; they are not fabricated screenshots or measured benchmark results. Add your own compiler/console screenshots before submission.
