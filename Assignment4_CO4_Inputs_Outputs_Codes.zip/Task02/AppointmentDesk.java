import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class AppointmentDesk extends JFrame {
    private final JTextField patientId = new JTextField(14);
    private final JComboBox<String> department = new JComboBox<>(new String[]{"Cardiology", "Dental", "Orthopedics"});
    private final JComboBox<String> doctor = new JComboBox<>();
    private final JComboBox<String> slot = new JComboBox<>(new String[]{"09:00", "10:30", "14:00"});
    private final JLabel status = new JLabel("Enter details and book.");
    private boolean bookingInProgress = false;
    private final Map<String, String[]> doctors = new LinkedHashMap<>();

    public AppointmentDesk() {
        super("Hospital Appointment Desk");
        doctors.put("Cardiology", new String[]{"Dr. Rao", "Dr. Meena"});
        doctors.put("Dental", new String[]{"Dr. Kumar", "Dr. Priya"});
        doctors.put("Orthopedics", new String[]{"Dr. Shah"});
        JPanel form = new JPanel(new GridLayout(5, 2, 8, 8));
        form.add(new JLabel("Patient ID")); form.add(patientId);
        form.add(new JLabel("Department")); form.add(department);
        form.add(new JLabel("Doctor")); form.add(doctor);
        form.add(new JLabel("Time slot")); form.add(slot);
        JButton book = new JButton("Book");
        JButton clear = new JButton("Clear");
        form.add(book); form.add(clear);
        add(form, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        department.addActionListener(e -> refreshDoctors());
        book.addActionListener(e -> bookAppointment());
        clear.addActionListener(e -> { patientId.setText(""); status.setText("Form cleared."); });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (bookingInProgress && JOptionPane.showConfirmDialog(AppointmentDesk.this,
                    "A booking is in progress. Close anyway?", "Confirm",
                    JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
                dispose();
            }
        });
        refreshDoctors();
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(470, 260);
        setLocationRelativeTo(null);
    }

    private void refreshDoctors() {
        doctor.removeAllItems();
        String[] list = doctors.get((String) department.getSelectedItem());
        if (list != null) for (String name : list) doctor.addItem(name);
        doctor.setEnabled(doctor.getItemCount() > 0);
    }

    private void bookAppointment() {
        if (patientId.getText().trim().isEmpty()) { status.setText("Enter patient ID."); return; }
        if (doctor.getSelectedItem() == null || slot.getSelectedItem() == null) {
            status.setText("Select department, doctor and time slot."); return;
        }
        bookingInProgress = true;
        String ref = "APT-" + (1000 + new Random().nextInt(9000));
        status.setText("Booking confirmed. Reference: " + ref);
        bookingInProgress = false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppointmentDesk().setVisible(true));
    }
}
