import java.util.Scanner;

public class Q1_ATM {
    static class InvalidWithdrawalException extends RuntimeException {
        InvalidWithdrawalException(String message) { super(message); }
    }

    static void withdraw(String account, int amount, int balance) {
        try {
            if (account == null || account.trim().isEmpty())
                throw new IllegalArgumentException("Account number is required");
            if (amount < 0)
                throw new InvalidWithdrawalException("Withdrawal amount cannot be negative");
            if (amount > balance)
                throw new InvalidWithdrawalException("Insufficient balance");
            System.out.println("Withdrawal successful: Rs." + amount);
            System.out.println("Remaining balance: Rs." + (balance - amount));
        } catch (IllegalArgumentException e) {
            System.out.println("Input error: " + e.getMessage());
        } catch (InvalidWithdrawalException e) {
            System.out.println("Transaction rejected: " + e.getMessage());
        } finally {
            System.out.println("ATM session closed.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter account number: ");
            String account = sc.nextLine();
            System.out.print("Enter withdrawal amount: ");
            String raw = sc.nextLine();
            int amount = Integer.parseInt(raw);
            withdraw(account, amount, 5000);
        } catch (NumberFormatException e) {
            System.out.println("Input error: Amount must be a whole number.");
            System.out.println("ATM session closed.");
        } finally {
            sc.close();
        }
    }
}
