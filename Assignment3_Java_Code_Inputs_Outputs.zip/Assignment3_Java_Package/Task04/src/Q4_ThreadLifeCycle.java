public class Q4_ThreadLifeCycle {
    static class ScannerStation extends Thread {
        private final int station;
        private final int scripts;

        ScannerStation(int station, int scripts) {
            this.station = station;
            this.scripts = scripts;
        }

        public void run() {
            try {
                Thread.sleep(100L * station);
                System.out.println("Station " + station + " scanned " + scripts + " scripts.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Station " + station + " interrupted.");
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new ScannerStation(i + 1, 25);
            stations[i].start();
        }
        for (Thread t : stations) t.join();
        System.out.println("All stations completed. Total scanned: 100");
    }
}
