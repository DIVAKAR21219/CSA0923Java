CREATE TABLE wallet (
  wallet_id VARCHAR(30) PRIMARY KEY,
  balance DECIMAL(12,2) NOT NULL CHECK (balance >= 0)
);
INSERT INTO wallet(wallet_id, balance) VALUES ('HOSTEL', 1500.00), ('CANTEEN', 200.00);
