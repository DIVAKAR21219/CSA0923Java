# Task 6 - Inheritance hierarchy
TwoWheeler, Car, EBike, and DeliveryVan extend Vehicle. ElectricCar extends Car. ElectricCar and EBike implement Chargeable.
