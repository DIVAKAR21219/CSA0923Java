import java.io.*;

public class LineCounter {
    public static long count(String path, boolean buffered) throws IOException {
        long lines = 0;
        InputStream raw = new FileInputStream(path);
        try (InputStream in = buffered ? new BufferedInputStream(raw, 64 * 1024) : raw) {
            int value;
            while ((value = in.read()) != -1) if (value == '\n') lines++;
        }
        return lines;
    }
    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : "sample.txt";
        System.out.println("Unbuffered line-feed count: " + count(path, false));
        System.out.println("Buffered line-feed count: " + count(path, true));
    }
}
