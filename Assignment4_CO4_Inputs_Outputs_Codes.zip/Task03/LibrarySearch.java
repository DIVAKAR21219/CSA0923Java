import java.awt.*;
import javax.swing.*;

public class LibrarySearch extends JFrame {
    private final JTextField searchText = new JTextField(22);
    private final JComboBox<String> category =
        new JComboBox<>(new String[]{"All", "Books", "Journals", "Theses"});
    private final DefaultListModel<String> model = new DefaultListModel<>();
    private final JList<String> results = new JList<>(model);
    private final JLabel status = new JLabel("Enter a title or keyword.");

    public LibrarySearch() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8, 8));
        JLabel title = new JLabel("Campus Library Search", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        add(title, BorderLayout.NORTH);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(new JLabel("Search:"));
        searchRow.add(searchText);
        searchRow.add(category);
        JButton search = new JButton("Search");
        searchRow.add(search);
        JPanel center = new JPanel(new BorderLayout());
        center.add(searchRow, BorderLayout.NORTH);
        center.add(new JScrollPane(results), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prev = new JButton("Prev"), next = new JButton("Next"), reserve = new JButton("Reserve");
        buttons.add(prev); buttons.add(next); buttons.add(reserve);
        JPanel south = new JPanel(new BorderLayout());
        south.add(buttons, BorderLayout.CENTER);
        south.add(status, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        search.addActionListener(e -> performSearch());
        searchText.addActionListener(e -> performSearch());
        prev.addActionListener(e -> status.setText("Previous page selected."));
        next.addActionListener(e -> status.setText("Next page selected."));
        reserve.addActionListener(e -> {
            if (results.getSelectedValue() == null) status.setText("Select a result before reserving.");
            else status.setText("Reservation requested: " + results.getSelectedValue());
        });
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(520, 360));
        setSize(720, 480);
        setLocationRelativeTo(null);
    }

    private void performSearch() {
        String query = searchText.getText().trim();
        model.clear();
        if (query.isEmpty()) { status.setText("Enter a search term."); return; }
        model.addElement("Example result for: " + query);
        status.setText("1 result shown in category " + category.getSelectedItem());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearch().setVisible(true));
    }
}
