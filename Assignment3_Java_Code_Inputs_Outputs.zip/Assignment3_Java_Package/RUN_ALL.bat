@echo off
setlocal
for %%D in (Task01 Task02 Task03 Task04 Task05 Task06 Task07) do (
  echo ==== %%D ====
  cd %%D
  if not exist bin mkdir bin
  for %%F in (src\*.java) do javac -d bin %%F
  for %%F in (src\*.java) do (
    for %%C in (%%~nF) do java -cp bin %%C
  )
  cd ..
)
endlocal
