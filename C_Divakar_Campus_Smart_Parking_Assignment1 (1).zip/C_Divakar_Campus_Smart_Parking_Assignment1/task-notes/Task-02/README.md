# Task 2 - Data representation
The implementation uses int for floor/slot indexes, String for registration numbers, LocalDateTime for ticket entry time, double for illustrative fees, a jagged String[][] for unequal floor capacities, and HashMap for active tickets.
