# Task 1 - Problem analysis
Objects: ParkingFacility, abstract Vehicle, vehicle subtypes, ParkingTicket, Chargeable, and PassHolder. Inputs and outputs and business rules are listed in `../..//inputs/sample-inputs.txt` and the main project README.
