# Task 6 database starter
Run `schema.sql` in MySQL first. Add MySQL Connector/J to the classpath. Configure `DB_URL`, `DB_USER`, and `DB_PASSWORD` as environment variables before running a client that uses `EventRegistrationRepository`.

Compile repository class (JDK only; JDBC driver is needed at runtime):
```bash
javac EventRegistrationRepository.java
```
This folder contains the SQL schema and JDBC repository example from the report, plus test inputs/expected behaviours. The report explicitly notes that the full Swing registration/committee screens, CSV export, and SwingWorker integration must be completed and tested locally; this archive does not claim a complete operational database application.
