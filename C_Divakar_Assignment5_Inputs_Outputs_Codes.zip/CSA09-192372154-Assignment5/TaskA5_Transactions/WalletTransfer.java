import java.sql.*;

public class WalletTransfer {
    public static void transfer(Connection c, String from, String to, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        boolean oldAutoCommit = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            try (PreparedStatement debit = c.prepareStatement(
                    "UPDATE wallet SET balance = balance - ? WHERE wallet_id = ? AND balance >= ?")) {
                debit.setDouble(1, amount); debit.setString(2, from); debit.setDouble(3, amount);
                if (debit.executeUpdate() != 1) throw new SQLException("Insufficient funds or source missing");
            }
            try (PreparedStatement credit = c.prepareStatement(
                    "UPDATE wallet SET balance = balance + ? WHERE wallet_id = ?")) {
                credit.setDouble(1, amount); credit.setString(2, to);
                if (credit.executeUpdate() != 1) throw new SQLException("Destination wallet missing");
            }
            c.commit();
        } catch (SQLException | RuntimeException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(oldAutoCommit);
        }
    }
}
