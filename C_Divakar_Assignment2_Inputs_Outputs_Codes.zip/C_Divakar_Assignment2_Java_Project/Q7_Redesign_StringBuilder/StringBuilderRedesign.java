public class StringBuilderRedesign {
    static String original(String[] fields) {
        String result = "";
        for (String field : fields) result = result + field + "|";
        return result;
    }
    static String redesigned(String[] fields) {
        int capacity = 0;
        for (String field : fields) capacity += field.length() + 1;
        StringBuilder ticket = new StringBuilder(capacity);
        for (String field : fields) ticket.append(field).append('|');
        return ticket.toString();
    }
    public static void main(String[] args) {
        String[] fields = {"PNR:123", "Name:Divakar", "Coach:S1", "Berth:21"};
        String a = original(fields);
        String b = redesigned(fields);
        System.out.println("Original: " + a);
        System.out.println("Redesigned: " + b);
        System.out.println("Outputs identical: " + a.equals(b));
    }
}
