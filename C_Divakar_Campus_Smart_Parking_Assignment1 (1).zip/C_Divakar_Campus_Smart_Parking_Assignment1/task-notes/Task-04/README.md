# Task 4 - Classes, objects, constructors
Vehicle and ParkingTicket use parameterized constructors. Subclasses call super(regNo), centralizing registration validation.
