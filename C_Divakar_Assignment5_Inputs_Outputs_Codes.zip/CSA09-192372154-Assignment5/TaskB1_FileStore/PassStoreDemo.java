import java.nio.file.*;
import java.time.LocalDate;
import java.util.Arrays;

public class PassStoreDemo {
    public static void main(String[] args) throws Exception {
        Path file = Path.of("passes.csv");
        Files.writeString(file,
            "P1001,192311001,Arun,7,2027-03-31,3800.0\n" +
            "P1002,192311002,damaged-row\n" +
            "P1003,192311003,Divya,7,2027-03-31,3800.0\n");
        PassStore store = new PassStore(file);
        System.out.println(Arrays.toString(store.find("P1003")));
        System.out.println(store.find("P9999"));
        System.out.println("Route 7 valid records: " + store.listByRoute(7).size());
    }
}
