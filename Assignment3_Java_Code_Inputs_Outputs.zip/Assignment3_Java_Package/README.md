# Java Assignment 3 – CO3
**Student:** C Divakar  
**Register number:** 192372154  
**Course code:** CSA0923  
**Topic:** Exception Handling and Multithreading  
**Java requirement:** Java 11 or later (Q7 uses Files.readString/writeString).

## Contents
- `Task01` to `Task07`: Java source, sample input files where applicable, expected output, and execution logs.
- `README.md`: this guide.
- `RUN_ALL.bat`: Windows helper to compile and run each task.
- `RUN_ALL.sh`: Linux/macOS helper to compile and run each task.

## Compile and run one task
Open a terminal in the relevant task folder and run:
```bash
javac -d bin src/Q1_ATM.java
java -cp bin Q1_ATM
```
Replace the class name with the matching task:
- Q1: `Q1_ATM`
- Q2: `Q2_StorageDemo`
- Q3: `Q3_ResourceSafety`
- Q4: `Q4_ThreadLifeCycle`
- Q5: `Q5_SeatBooking`
- Q6: `Q6_TokenCounter`
- Q7: `Q7_ResultProcessor`

For Q1, enter an account number and a withdrawal amount when prompted.  
Q3 reads sample sales files from `input/` and writes `output/summary.txt`.  
Q7 creates its sample score files under `input/scores/` when it runs.

## Outputs and evidence
`output/expected_output.txt` contains the expected/illustrative result. If a `run_output.txt` is present, it was captured by running the program in the build environment. Thread scheduling can change print order in Q4 and Q5. Performance measurements and screenshots must be captured on your own computer; do not submit illustrative outputs as measured evidence.

## Submission checklist
1. Open each task folder and compile/run its Java file.
2. Capture genuine screenshots of compilation and execution.
3. Complete repeated-run observations and performance measurement tables from your own runs.
4. Add screenshots to the matching `evidence/` folder.
5. Commit each task separately to your GitHub repository.
