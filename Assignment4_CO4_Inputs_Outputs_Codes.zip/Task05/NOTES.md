The same ActionListener is registered on both the Convert button and amount field, so pressing Enter also converts. The supplied rates are USD=0.012 and EUR=0.011.
