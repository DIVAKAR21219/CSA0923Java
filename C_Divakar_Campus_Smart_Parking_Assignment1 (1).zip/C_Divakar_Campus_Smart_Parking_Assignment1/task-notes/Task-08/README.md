# Task 8 - Polymorphism
Vehicle provides overloaded calculateFee(int) and calculateFee(LocalDateTime, LocalDateTime). Calls to ratePerHour() dispatch to the actual vehicle subtype at runtime.
