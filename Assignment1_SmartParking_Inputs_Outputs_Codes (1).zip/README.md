# Assignment 1 – Campus Smart-Parking System
Based on the uploaded `C_Divakar_Assignment1.pdf` (7 pages).

## Package contents
- `ParkingSystem.java`: complete runnable Java implementation covering the core OOP model.
- `inputs/sample-inputs.txt`: sample test data and validation cases.
- `outputs/expected-output.txt`: expected console output.
- `Task01` through `Task12`: one folder per task, each with notes, inputs and expected results.

## Compile and run
Requires JDK 8 or later.
```bash
javac ParkingSystem.java
java ParkingSystem
```
The sample console output is recorded in `outputs/expected-output.txt`.

## Assignment assumptions retained
- Two-wheeler: Rs 10/hour
- Car: Rs 30/hour
- Delivery van: Rs 60/hour
- EV charging: Rs 12/kWh
- Every started hour is billed as a full hour.
- Floor capacities use a jagged array to support unequal floor sizes.
- A valid pass waives parking fee; charging remains separate.

## Notes
The source PDF identifies these tariff values as illustrative assumptions, not university-confirmed rates. The sample implementation is a console demonstration. The PDF describes a one-day pass contract and recommends a separate pricing strategy for a production deployment; the sample keeps pass validity as a boolean argument to the exit operation. Review and execute the code locally before submission, capture genuine screenshots, and record the actual `java -version`.
