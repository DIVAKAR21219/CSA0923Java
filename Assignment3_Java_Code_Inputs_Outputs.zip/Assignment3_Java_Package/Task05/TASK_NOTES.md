# Task 05

Java source is in `src/`. Sample input files (where needed) are in `input/`.
- `output/expected_output.txt`: expected or illustrative output from the assignment.
- `output/compile.txt`: compilation status from the build environment.
- `output/run_output.txt`: captured program output, when Java was available.
- `evidence/`: place your own genuine screenshots here.

Run from this task directory:
```bash
javac -d bin src/Q5_SeatBooking.java
java -cp bin Q5_SeatBooking
```
