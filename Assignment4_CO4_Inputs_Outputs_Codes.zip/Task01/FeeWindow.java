import java.awt.*;
import java.awt.event.*;

public class FeeWindow extends Frame {
    private final TextField regNo = new TextField(15);
    private final TextField amount = new TextField(10);
    private final Label status = new Label("Ready");

    public FeeWindow() {
        super("Student Fee Payment – Design Demo");
        setLayout(new GridLayout(4, 2, 8, 8));
        add(new Label("Registration number:")); add(regNo);
        add(new Label("Amount (INR):")); add(amount);
        Button pay = new Button("Pay");
        Button clear = new Button("Clear");
        add(pay); add(clear);
        add(new Label("Status:")); add(status);
        pay.addActionListener(e -> submitPayment());
        clear.addActionListener(e -> {
            regNo.setText(""); amount.setText(""); status.setText("Ready");
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(430, 190);
        setLocationRelativeTo(null);
    }

    private void submitPayment() {
        String reg = regNo.getText().trim();
        if (reg.isEmpty()) { status.setText("Enter registration number."); return; }
        try {
            double value = Double.parseDouble(amount.getText().trim());
            if (!Double.isFinite(value) || value <= 0) {
                status.setText("Amount must be greater than zero."); return;
            }
            // Demo only: no real payment or database transaction is performed.
            status.setText("Demo payment accepted: INR " + String.format("%.2f", value));
        } catch (NumberFormatException ex) {
            status.setText("Enter a valid amount.");
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new FeeWindow().setVisible(true));
    }
}
