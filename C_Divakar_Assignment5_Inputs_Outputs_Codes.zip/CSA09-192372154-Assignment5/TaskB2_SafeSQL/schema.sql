CREATE DATABASE IF NOT EXISTS assignment5;
USE assignment5;
CREATE TABLE IF NOT EXISTS app_user (
  user_id VARCHAR(80) PRIMARY KEY,
  password_hash VARCHAR(255) NOT NULL
);
INSERT INTO app_user(user_id, password_hash)
VALUES ('test-user', 'demo-hash')
ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash);
