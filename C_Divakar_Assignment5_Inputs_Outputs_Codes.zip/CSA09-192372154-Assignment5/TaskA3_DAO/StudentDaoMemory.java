import java.util.*;

public class StudentDaoMemory implements Dao<Student, Long> {
    private final Map<Long, Student> data = new LinkedHashMap<>();
    public Long insert(Student s) { data.put(s.id(), s); return s.id(); }
    public Optional<Student> findById(Long id) { return Optional.ofNullable(data.get(id)); }
    public List<Student> findAll() { return new ArrayList<>(data.values()); }
    public boolean update(Student s) {
        if (!data.containsKey(s.id())) return false;
        data.put(s.id(), s); return true;
    }
    public boolean delete(Long id) { return data.remove(id) != null; }
    public static void main(String[] args) {
        StudentDaoMemory dao = new StudentDaoMemory();
        dao.insert(new Student(1, "Arun", "arun@example.com"));
        dao.insert(new Student(2, "Divya", "divya@example.com"));
        System.out.println(dao.findById(1L).orElse(null));
        System.out.println("Student count: " + dao.findAll().size());
    }
}
