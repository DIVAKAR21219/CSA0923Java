This is a local event-flow demonstration. It uses sample doctor data and does not connect to a hospital booking database.
