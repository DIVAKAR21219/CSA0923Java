# CSA09-192372154-Assignment5 — Programming in Java (CO5)

**Student:** C Divakar  
**Register No:** 192372154  
**Course Code:** CSA0923  
**Topic:** Data Persistence Engineering — Files and Databases

## Folder guide
- `TaskA1_FileFormat`: CSV and binary record format examples and design notes.
- `TaskA2_Buffering`: buffered line counter and sample input.
- `TaskA3_DAO`: generic DAO pattern example and interface.
- `TaskA4_Serialization`: serializable model with transient JDBC resource/password exclusion.
- `TaskA5_Transactions`: JDBC transaction example for wallet transfer.
- `TaskB1_FileStore`: bus-pass CSV file store, damaged-row handling, demo and line counter.
- `TaskB2_SafeSQL`: safe PreparedStatement demonstration using a local test database.
- `TaskB3_JDBC_Batch`: schema and batch loader for MySQL.
- `TaskB4_Migration`: migration plan and engineering decision.

## Requirements
- JDK 17 or later recommended.
- MySQL Server and MySQL Connector/J are needed only for Task A5, Task B2 and Task B3 database examples.
- Set database credentials with environment variables `DB_URL`, `DB_USER`, and `DB_PASSWORD`. Do not put real passwords in source files.

## Compile/run examples
From a task folder:
```bash
javac *.java
java PassStoreDemo
```
For Task B3, add MySQL Connector/J to the classpath when running:
```bash
javac PassLoader.java
java -cp ".;mysql-connector-j.jar" PassLoader
```
On macOS/Linux replace `;` with `:` in the classpath.

## Evidence
`expected_output.txt` gives the expected sample result. Where an output depends on local files, MySQL, JDK, or timing, run it on your own machine and save genuine screenshots/results. No machine-specific benchmark values or database execution results are invented in this pack.
