import java.io.*;
import java.util.*;

public class Q3_ResourceSafety {
    static void generateReport(List<String> files, String output) throws IOException {
        int total = 0;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(output))) {
            for (String file : files) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        try {
                            total += Integer.parseInt(line.trim());
                        } catch (NumberFormatException e) {
                            System.err.println("Invalid sales value in " + file + ": " + line.trim());
                        }
                    }
                } catch (FileNotFoundException e) {
                    System.err.println("Missing input file " + file + ": " + e.getMessage());
                }
            }
            writer.write("Total sales: " + total);
            writer.newLine();
        }
    }

    public static void main(String[] args) throws IOException {
        List<String> files = Arrays.asList("input/store1.txt", "input/store2.txt", "input/store3.txt");
        generateReport(files, "output/summary.txt");
        System.out.println("Report generated: output/summary.txt");
    }
}
