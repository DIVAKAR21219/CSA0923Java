import java.io.*;
import java.util.*;

class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    final String regNo, name;
    Resident(String regNo, String name) { this.regNo = regNo; this.name = name; }
}
class Room implements Serializable {
    private static final long serialVersionUID = 1L;
    final int roomNo;
    final List<Resident> residents = new ArrayList<>();
    Room(int roomNo) { this.roomNo = roomNo; }
}
public class HostelSnapshot {
    private static final long serialVersionUID = 1L;
    final List<Room> rooms = new ArrayList<>();
    transient Object liveJdbcConnection; // runtime resource is not persisted
    transient String password;           // do not serialize plaintext credentials

    public static void main(String[] args) throws Exception {
        HostelSnapshot h = new HostelSnapshot();
        Room r = new Room(101);
        r.residents.add(new Resident("192311001", "Arun"));
        h.rooms.add(r);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("hostel.dat"))) {
            out.writeObject(h);
        }
        System.out.println("Hostel snapshot saved");
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("hostel.dat"))) {
            HostelSnapshot loaded = (HostelSnapshot) in.readObject();
            System.out.println("Rooms loaded: " + loaded.rooms.size());
            System.out.println("Residents in room 101: " + loaded.rooms.get(0).residents.size());
        }
    }
}
