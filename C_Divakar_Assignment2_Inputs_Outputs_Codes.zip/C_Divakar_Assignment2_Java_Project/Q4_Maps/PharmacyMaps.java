import java.util.*;

public class PharmacyMaps {
    public static void main(String[] args) {
        Map<String, Integer> hash = new HashMap<>();
        Map<String, Integer> tree = new TreeMap<>();
        Map<String, Integer> linked = new LinkedHashMap<>();
        String[][] stock = {
            {"M103", "25"}, {"M101", "40"}, {"M105", "12"}, {"M102", "30"}
        };
        for (String[] row : stock) {
            int quantity = Integer.parseInt(row[1]);
            hash.put(row[0], quantity);
            tree.put(row[0], quantity);
            linked.put(row[0], quantity);
        }
        System.out.println("Lookup M101 = " + hash.get("M101"));
        System.out.println("Code order = " + tree);
        System.out.println("Insertion order = " + linked);
    }
}
