public record Student(long id, String name, String email) {}
