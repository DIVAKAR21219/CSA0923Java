The corrected callback is mouseClicked(MouseEvent e) with capital C. @Override catches spelling errors at compile time. Points are stored in a List and redrawn in paint().
