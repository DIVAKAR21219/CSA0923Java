import java.time.LocalDate;

public class PassRecord {
    public final String passId, registerNo, name;
    public final int routeNo;
    public final LocalDate validityDate;
    public final double amountPaid;

    public PassRecord(String passId, String registerNo, String name,
                      int routeNo, LocalDate validityDate, double amountPaid) {
        if (passId == null || passId.isBlank() || registerNo == null || registerNo.isBlank())
            throw new IllegalArgumentException("Pass ID and register number are required");
        if (routeNo < 0 || amountPaid < 0) throw new IllegalArgumentException("Invalid route/amount");
        this.passId = passId; this.registerNo = registerNo; this.name = name;
        this.routeNo = routeNo; this.validityDate = validityDate; this.amountPaid = amountPaid;
    }
    @Override public String toString() {
        return passId + "," + registerNo + "," + name + "," + routeNo + "," +
               validityDate + "," + amountPaid;
    }
}
