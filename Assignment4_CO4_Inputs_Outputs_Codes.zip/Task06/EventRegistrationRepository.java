import java.sql.*;
import java.util.*;

public class EventRegistrationRepository {
    private final String url = System.getenv().getOrDefault("DB_URL",
        "jdbc:mysql://localhost:3306/campus_events");
    private final String user = System.getenv().getOrDefault("DB_USER", "root");
    private final String password = System.getenv().getOrDefault("DB_PASSWORD", "");

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public void register(String studentId, String studentName, int eventId) throws SQLException {
        String sql = "INSERT INTO registrations(student_id, student_name, event_id) VALUES (?, ?, ?)";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, studentName);
            ps.setInt(3, eventId);
            ps.executeUpdate();
        }
    }

    public List<String[]> findPage(Integer eventId, int limit, int offset) throws SQLException {
        String base = "SELECT r.registration_id, r.student_id, r.student_name, e.event_name, " +
                      "r.registered_at FROM registrations r JOIN events e ON e.event_id=r.event_id ";
        String sql = base + (eventId == null ? "" : "WHERE r.event_id=? ") +
                     "ORDER BY r.registration_id DESC LIMIT ? OFFSET ?";
        List<String[]> rows = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            if (eventId != null) ps.setInt(i++, eventId);
            ps.setInt(i++, limit);
            ps.setInt(i, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new String[] {
                    rs.getString("registration_id"), rs.getString("student_id"),
                    rs.getString("student_name"), rs.getString("event_name"),
                    rs.getString("registered_at")
                });
            }
        }
        return rows;
    }
}
