import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;

public class RecordFormatDemo {
    public static void main(String[] args) throws Exception {
        PassRecord p = new PassRecord("P1001", "192311001", "Arun Kumar",
                7, LocalDate.parse("2027-03-31"), 3800.0);
        Path text = Path.of("passes.csv");
        Files.writeString(text, "passId,registerNo,name,routeNo,validityDate,amountPaid\n" + p + "\n");
        try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(Path.of("passes.bin")))) {
            out.writeInt(1); // format version
            out.writeUTF(p.passId); out.writeUTF(p.registerNo); out.writeUTF(p.name);
            out.writeInt(p.routeNo); out.writeUTF(p.validityDate.toString());
            out.writeDouble(p.amountPaid);
        }
        System.out.println("Text record written: " + p);
        System.out.println("Binary record written: passes.bin");
    }
}
