#!/bin/sh
set -e
for d in Task01 Task02 Task03 Task04 Task05 Task06 Task07; do
  echo "==== $d ===="
  cd "$d"
  mkdir -p bin
  for f in src/*.java; do javac -d bin "$f"; done
  for f in src/*.java; do cls=$(basename "$f" .java); java -cp bin "$cls"; done
  cd ..
done
