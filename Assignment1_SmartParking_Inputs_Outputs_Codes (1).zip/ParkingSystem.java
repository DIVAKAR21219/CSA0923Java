import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

interface Chargeable {
    double chargingFee(double energyKwh);
}

interface PassHolder {
    boolean hasValidPass();
}

abstract class Vehicle {
    private final String registrationNumber;

    protected Vehicle(String registrationNumber) {
        if (registrationNumber == null || registrationNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Registration number is required");
        }
        this.registrationNumber = registrationNumber.trim();
    }

    public final String getRegistrationNumber() { return registrationNumber; }
    public abstract double ratePerHour();

    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Negative duration");
        int hours = (minutes + 59) / 60; // every started hour is billed
        return hours * ratePerHour();
    }

    public double calculateFee(LocalDateTime in, LocalDateTime out) {
        if (in == null || out == null || out.isBefore(in)) {
            throw new IllegalArgumentException("Invalid entry/exit time");
        }
        long minutes = Duration.between(in, out).toMinutes();
        if (minutes > Integer.MAX_VALUE) throw new IllegalArgumentException("Duration too large");
        return calculateFee((int) minutes);
    }

    @Override public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Vehicle)) return false;
        Vehicle v = (Vehicle) other;
        return registrationNumber.equals(v.registrationNumber);
    }

    @Override public int hashCode() { return Objects.hash(registrationNumber); }
}

class TwoWheeler extends Vehicle {
    TwoWheeler(String reg) { super(reg); }
    @Override public double ratePerHour() { return 10.0; }
}

class Car extends Vehicle {
    Car(String reg) { super(reg); }
    @Override public double ratePerHour() { return 30.0; }
}

class ElectricCar extends Car implements Chargeable {
    ElectricCar(String reg) { super(reg); }
    @Override public double chargingFee(double energyKwh) {
        if (energyKwh < 0) throw new IllegalArgumentException("Negative charging energy");
        return energyKwh * 12.0;
    }
}

class EBike extends Vehicle implements Chargeable {
    EBike(String reg) { super(reg); }
    @Override public double ratePerHour() { return 0.0; } // flat/pass policy can be added separately
    @Override public double chargingFee(double energyKwh) {
        if (energyKwh < 0) throw new IllegalArgumentException("Negative charging energy");
        return energyKwh * 12.0;
    }
}

class DeliveryVan extends Vehicle {
    DeliveryVan(String reg) { super(reg); }
    @Override public double ratePerHour() { return 60.0; }
}

class OneDayPass implements PassHolder {
    private final String visitorId;
    private final java.time.LocalDate validOn;

    OneDayPass(String visitorId, java.time.LocalDate validOn) {
        if (visitorId == null || visitorId.trim().isEmpty() || validOn == null)
            throw new IllegalArgumentException("Visitor ID and pass date are required");
        this.visitorId = visitorId;
        this.validOn = validOn;
    }

    @Override public boolean hasValidPass() {
        return validOn.equals(java.time.LocalDate.now());
    }
    public String getVisitorId() { return visitorId; }
}

class ParkingTicket {
    private static long nextId = 1001;
    private final long ticketNumber;
    private final Vehicle vehicle;
    private final int floor;
    private final int slot;
    private final LocalDateTime entryTime;
    private boolean active;

    ParkingTicket(Vehicle vehicle, int floor, int slot) {
        this.ticketNumber = nextId++;
        this.vehicle = vehicle;
        this.floor = floor;
        this.slot = slot;
        this.entryTime = LocalDateTime.now();
        this.active = true;
    }

    public long getTicketNumber() { return ticketNumber; }
    public Vehicle getVehicle() { return vehicle; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public LocalDateTime getEntryTime() { return entryTime; }
    public boolean isActive() { return active; }
    public void close() { active = false; }
}

class ParkingFacility {
    private static int totalFacilities = 0;
    private final String[][] slots;
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();

    ParkingFacility(int[] capacities) {
        if (capacities == null || capacities.length == 0)
            throw new IllegalArgumentException("At least one floor is required");
        slots = new String[capacities.length][];
        for (int i = 0; i < capacities.length; i++) {
            if (capacities[i] < 0) throw new IllegalArgumentException("Negative slot capacity");
            slots[i] = new String[capacities[i]];
        }
        totalFacilities++;
    }

    public static int getTotalFacilities() { return totalFacilities; }

    public int[] allocate(String vehicleNo) {
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = vehicleNo;
                    return new int[]{f, s};
                }
            }
        }
        return null;
    }

    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length) return false;
        if (slot < 0 || slot >= slots[floor].length) return false;
        if (slots[floor][slot] == null) return false;
        slots[floor][slot] = null;
        return true;
    }

    public ParkingTicket enter(Vehicle vehicle) {
        if (vehicle == null) throw new IllegalArgumentException("Vehicle is required");
        String reg = vehicle.getRegistrationNumber();
        if (activeTickets.containsKey(reg))
            throw new IllegalStateException("Vehicle already has an active ticket");
        int[] location = allocate(reg);
        if (location == null) return null;
        ParkingTicket ticket = new ParkingTicket(vehicle, location[0], location[1]);
        activeTickets.put(reg, ticket);
        return ticket;
    }

    public double exit(String registrationNumber, int minutes, double energyKwh, boolean validPass) {
        ParkingTicket ticket = activeTickets.get(registrationNumber);
        if (ticket == null || !ticket.isActive())
            throw new IllegalArgumentException("No active ticket for registration");
        Vehicle vehicle = ticket.getVehicle();
        double parkingFee = validPass ? 0.0 : vehicle.calculateFee(minutes);
        double charging = vehicle instanceof Chargeable
            ? ((Chargeable) vehicle).chargingFee(energyKwh) : 0.0;
        release(ticket.getFloor(), ticket.getSlot());
        ticket.close();
        activeTickets.remove(registrationNumber);
        return parkingFee + charging;
    }

    public int getOccupancy() { return activeTickets.size(); }
    public ParkingTicket findTicket(String registrationNumber) {
        return activeTickets.get(registrationNumber);
    }
}

public class ParkingSystem {
    private static String location(int[] a) {
        return a == null ? "null" : "[" + a[0] + ", " + a[1] + "]";
    }

    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 1});
        System.out.println(location(facility.allocate("TEMP1")));
        System.out.println(location(facility.allocate("TEMP2")));
        System.out.println(location(facility.allocate("TEMP3")));
        System.out.println(location(facility.allocate("TEMP4")));
        System.out.println(facility.release(0, 0) + " " + facility.release(0, 0)
            + " " + facility.release(9, 0));
        System.out.println(location(facility.allocate("REUSE")));
        facility.release(0, 0);
        facility.release(0, 1);
        facility.release(1, 0);

        Vehicle bike = new TwoWheeler("TNGA1");
        Vehicle car = new Car("TN2B2");
        Vehicle ev = new ElectricCar("TN3C3");
        System.out.println("TwoWheeler " + bike.getRegistrationNumber() + " -> Rs "
            + bike.calculateFee(130));
        System.out.println("Car " + car.getRegistrationNumber() + " -> Rs "
            + car.calculateFee(130));
        System.out.println("ElectricCar " + ev.getRegistrationNumber() + " -> Rs "
            + (ev.calculateFee(130) + ((Chargeable) ev).chargingFee(10)));
        System.out.println(new Car("SAME").equals(new ElectricCar("SAME")));

        ParkingTicket ticket = facility.enter(new TwoWheeler("TICKET1"));
        System.out.println("Ticket " + ticket.getTicketNumber() + " issued; slot="
            + ticket.getFloor() + "," + ticket.getSlot());
        System.out.println("Delivery van fee for 61 minutes = Rs "
            + new DeliveryVan("VAN1").calculateFee(61));
        facility.exit("TICKET1", 30, 0, false);
        System.out.println("Active occupancy = " + facility.getOccupancy());
    }
}
