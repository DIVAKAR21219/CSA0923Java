# Task 7 - Override and specialize behaviour
Each concrete vehicle overrides ratePerHour(). Vehicle also overrides equals() and hashCode() using registration number.
