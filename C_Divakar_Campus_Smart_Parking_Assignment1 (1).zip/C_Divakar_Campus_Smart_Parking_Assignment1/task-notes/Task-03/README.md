# Task 3 - Control logic
ParkingFacility.allocate scans each floor and slot and returns the first free coordinate. release validates coordinates and refuses to release an already-free slot. Fee hours use ceiling arithmetic: (minutes + 59) / 60.
