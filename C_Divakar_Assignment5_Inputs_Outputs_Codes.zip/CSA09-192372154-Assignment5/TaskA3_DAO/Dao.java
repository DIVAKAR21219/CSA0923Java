import java.util.*;

public interface Dao<T, K> {
    K insert(T value);
    Optional<T> findById(K id);
    List<T> findAll();
    boolean update(T value);
    boolean delete(K id);
}
