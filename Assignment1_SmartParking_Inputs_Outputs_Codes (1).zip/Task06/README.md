# Task 06

Inheritance hierarchy: Vehicle, TwoWheeler, Car, ElectricCar, EBike and DeliveryVan.

The shared runnable implementation is `../ParkingSystem.java`. Compile and run it from the project root using `javac ParkingSystem.java` and `java ParkingSystem`. Task-specific test inputs and expected outcomes are provided in this folder. The full test dataset is also in the root `inputs/` and `outputs/` folders.
