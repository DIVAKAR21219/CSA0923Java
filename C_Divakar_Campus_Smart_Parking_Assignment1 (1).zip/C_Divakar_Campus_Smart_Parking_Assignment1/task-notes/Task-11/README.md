# Task 11 - Implementation and testing
Compile and run using the commands in the root README. Compare the console output with `outputs/expected-output.txt`; the actual run is stored in `outputs/actual-output.txt`.
