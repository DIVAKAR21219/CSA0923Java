# Task 10 - Encapsulation and access
State fields are private; public methods expose controlled operations. Vehicle registration numbers are immutable after construction.
