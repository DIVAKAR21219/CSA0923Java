CREATE DATABASE IF NOT EXISTS assignment5;
USE assignment5;
CREATE TABLE IF NOT EXISTS bus_pass (
  pass_id VARCHAR(30) PRIMARY KEY,
  register_no VARCHAR(30) NOT NULL,
  student_name VARCHAR(120) NOT NULL,
  route_no INT NOT NULL,
  validity_date DATE NOT NULL,
  amount_paid DECIMAL(10,2) NOT NULL
);
