import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

interface Chargeable {
    double CHARGING_RATE_PER_KWH = 12.0;
    default double calculateChargingFee(double kwh) {
        if (kwh < 0) throw new IllegalArgumentException("Charging energy cannot be negative");
        return kwh * CHARGING_RATE_PER_KWH;
    }
}

interface PassHolder {
    boolean hasValidPass();
}

abstract class Vehicle {
    private final String registrationNumber;

    protected Vehicle(String registrationNumber) {
        if (registrationNumber == null || registrationNumber.isBlank())
            throw new IllegalArgumentException("Registration number is required");
        this.registrationNumber = registrationNumber;
    }

    public String getRegistrationNumber() { return registrationNumber; }
    public abstract double ratePerHour();

    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Negative duration");
        int hours = (minutes + 59) / 60;
        return hours * ratePerHour();
    }

    public double calculateFee(LocalDateTime in, LocalDateTime out) {
        if (in == null || out == null || out.isBefore(in))
            throw new IllegalArgumentException("Invalid entry/exit time");
        long minutes = Duration.between(in, out).toMinutes();
        if (minutes > Integer.MAX_VALUE) throw new IllegalArgumentException("Duration too large");
        return calculateFee((int) minutes);
    }

    @Override public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Vehicle)) return false;
        Vehicle vehicle = (Vehicle) other;
        return registrationNumber.equalsIgnoreCase(vehicle.registrationNumber);
    }
    @Override public int hashCode() { return registrationNumber.toUpperCase().hashCode(); }
}

class TwoWheeler extends Vehicle {
    TwoWheeler(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 10.0; }
    @Override public String toString() { return "TwoWheeler " + getRegistrationNumber(); }
}

class Car extends Vehicle {
    Car(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 30.0; }
    @Override public String toString() { return "Car " + getRegistrationNumber(); }
}

class ElectricCar extends Car implements Chargeable {
    ElectricCar(String regNo) { super(regNo); }
    @Override public String toString() { return "ElectricCar " + getRegistrationNumber(); }
}

class EBike extends Vehicle implements Chargeable {
    EBike(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 0.0; }
    @Override public String toString() { return "EBike " + getRegistrationNumber(); }
}

class DeliveryVan extends Vehicle {
    DeliveryVan(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 60.0; }
    @Override public String toString() { return "Delivery van " + getRegistrationNumber(); }
}

class ParkingTicket {
    private static int nextId = 1001;
    private final int ticketNumber;
    private final Vehicle vehicle;
    private final int floor;
    private final int slot;
    private final LocalDateTime entryTime;
    private boolean active;

    ParkingTicket(Vehicle vehicle, int floor, int slot) {
        this.ticketNumber = nextId++;
        this.vehicle = Objects.requireNonNull(vehicle);
        this.floor = floor;
        this.slot = slot;
        this.entryTime = LocalDateTime.now();
        this.active = true;
    }
    public int getTicketNumber() { return ticketNumber; }
    public Vehicle getVehicle() { return vehicle; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public boolean isActive() { return active; }
    public void close() { active = false; }
}

class ParkingFacility {
    private static int totalFacilities = 0;
    private final String[][] slots;
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();

    ParkingFacility(int[] capacities) {
        if (capacities == null || capacities.length == 0)
            throw new IllegalArgumentException("At least one floor is required");
        slots = new String[capacities.length][];
        for (int i = 0; i < capacities.length; i++) {
            if (capacities[i] < 0) throw new IllegalArgumentException("Capacity cannot be negative");
            slots[i] = new String[capacities[i]];
        }
        totalFacilities++;
    }
    public int[] allocate(String vehicleNo) {
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = vehicleNo;
                    return new int[]{f, s};
                }
            }
        }
        return null;
    }
    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length) return false;
        if (slot < 0 || slot >= slots[floor].length) return false;
        if (slots[floor][slot] == null) return false;
        slots[floor][slot] = null;
        return true;
    }
    public ParkingTicket enter(Vehicle vehicle) {
        String reg = vehicle.getRegistrationNumber();
        if (activeTickets.containsKey(reg)) throw new IllegalArgumentException("Vehicle already parked");
        int[] location = allocate(reg);
        if (location == null) return null;
        ParkingTicket ticket = new ParkingTicket(vehicle, location[0], location[1]);
        activeTickets.put(reg, ticket);
        return ticket;
    }
    public double exit(String registrationNumber, int minutes, double chargingKwh, boolean validPass) {
        ParkingTicket ticket = activeTickets.get(registrationNumber);
        if (ticket == null) throw new IllegalArgumentException("No active ticket for vehicle");
        Vehicle vehicle = ticket.getVehicle();
        double parkingFee = validPass ? 0.0 : vehicle.calculateFee(minutes);
        double chargingFee = vehicle instanceof Chargeable
                ? ((Chargeable) vehicle).calculateChargingFee(chargingKwh) : 0.0;
        release(ticket.getFloor(), ticket.getSlot());
        ticket.close();
        activeTickets.remove(registrationNumber);
        return parkingFee + chargingFee;
    }
    public int getOccupancy() {
        int count = 0;
        for (String[] floor : slots) for (String slot : floor) if (slot != null) count++;
        return count;
    }
    public static int getTotalFacilities() { return totalFacilities; }
}

public class ParkingSystem {
    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 1});
        int[] a = facility.allocate("TN01A1");
        int[] b = facility.allocate("TN02B2");
        int[] c = facility.allocate("TN03C3");
        System.out.println(java.util.Arrays.toString(a));
        System.out.println(java.util.Arrays.toString(b));
        System.out.println(java.util.Arrays.toString(c));
        System.out.println(facility.allocate("TN04D4"));
        System.out.println(facility.release(0, 0) + " " + facility.release(0, 0) + " " + facility.release(9, 0));
        int[] reused = facility.allocate("TN04D4");
        System.out.println(java.util.Arrays.toString(reused));
        System.out.println("TwoWheeler TN01A1 -> Rs " + new TwoWheeler("TN01A1").calculateFee(130));
        System.out.println("Car TN02B2 -> Rs " + new Car("TN02B2").calculateFee(130));
        ElectricCar ev = new ElectricCar("TN03C3");
        System.out.println("ElectricCar TN03C3 -> Rs " + (ev.calculateFee(130) + ev.calculateChargingFee(10)));
        System.out.println(new Car("TN02B2").equals(new ElectricCar("TN02B2")));
        ParkingTicket ticket = new ParkingTicket(new TwoWheeler("TN01A1"), 0, 0);
        System.out.println("Ticket " + ticket.getTicketNumber() + " issued; slot=" + ticket.getFloor() + "," + ticket.getSlot());
        System.out.println("Delivery van fee for 61 minutes = Rs " + new DeliveryVan("TN05V5").calculateFee(61));
        facility.release(0, 0);
        facility.release(0, 1);
        facility.release(1, 0);
        System.out.println("Active occupancy = " + facility.getOccupancy());
    }
}
